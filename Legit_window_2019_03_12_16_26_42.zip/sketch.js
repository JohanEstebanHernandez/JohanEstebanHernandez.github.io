var cruzList= [ ];

function setup() {
  //createCanvas(750,750);
	createCanvas(windowWidth,windowHeight);
  background(0);
 for (var i = 0; i < 10; i++){
    var cruzTemp = new Cruz(i*25, i*100);
    cruzList.push( cruzTemp );
  }
}
  
function draw() {  
 background(0);
  for (var j = 0; j < cruzList.length; j++)
  {
    var cruzTemp = cruzList[ j ];
    cruzTemp.display();
    cruzTemp.move();
      for (var i = 0; i < cruzList.length; i++) {
      if (dist(cruzList[ i ].xpos, cruzList[ i ].ypos, cruzList[ i ].xpos, cruzList[ i ].ypos) > -1) {
        stroke(random(128), random(87), random(255));
        line(cruzList[ j ].xpos, cruzList[ j ].ypos, cruzList[ i ].xpos, cruzList[ i ].ypos);
      }
    }
  }
}

class Cruz {

  constructor(posX, posY) {
    this.xpos=posX;
    this.ypos=posY;
    this.speed = 0.1;
    this.rot = 0;
    //this.pos;
  }

  display() {
    background(255);
    push();
    translate(this.xpos, this.ypos);
    fill(random(5), random(103), random(250));
    rotate(this.rot);
    rectMode(CENTER);
    rect(0, 0, 25, 100);
    rect(0, 0, 100, 25);
    pop();
    this.rot = this.rot + this.speed;
  }

  move() {
    if (mouseIsPressed == true) {
      this.speed = 2;
    }
    if (mouseIsPressed == false) {
      this.speed = 40;
    }
    this.xpos = this.xpos + this.speed;
    if (random(this.xpos) >= width) {
      this.xpos = -25;
    }
    this.ypos = this.ypos + this.speed;
    if (random(this.ypos) >= height) {
      this.ypos = -25;
    }
  }
}